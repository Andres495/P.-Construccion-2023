package Controllers;

import DAO.AvancesDAO;
import DAO.UsuarioDAO;
import POJO.Avance;
import POJO.Usuario;
import POJO.EntregaAvance;
import POJO.EntregaAvance;
import Utils.ShowMessage;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;


public class CalificarAvancesController implements Initializable {
    @FXML
    private TableView<Usuario> tvEstudiantes;
    @FXML
    private TableColumn<Usuario, String> ctMatricula;
    @FXML
    private TableColumn<Usuario, String> ctNombre;
    @FXML
    private TableColumn<Usuario, String> ctApellidoPat;
    @FXML
    private TextArea tfDescripcionEntrega;
    @FXML
    private ImageView ivArchivo;
    @FXML
    private Button btAdjuntar;
    @FXML
    private Button btCalificar2;
    @FXML
    private Button btCalificar;
    
    private ObservableList<Usuario> listaEstudiantes = null;
    private ObservableList<EntregaAvance> entregasEstud = null;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.configurarTabla();
        this.cargarAvances();
        this.tvEstudiantes.setOnMouseClicked(event -> {
            if (event.getClickCount() == 1) {
            }
        });
    }    
    
    
    @FXML
    private void clicDescargar(MouseEvent event) {
    }

    @FXML
    private void clicAdjuntar(ActionEvent event) {
    }

    @FXML
    private void confirmarCalificacion(ActionEvent event) {
    }

    @FXML
    private void clicCalificar(ActionEvent event) {
    }
    
    @FXML
    private void clicVolver(ActionEvent event) {
        try{
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/Views/ConsultarAvancesProfesor.fxml"));
            Parent root = loader.load();
        
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

            // Cerrar la ventana actual si es necesario
            Stage currentStage = (Stage)this.tvEstudiantes.getScene().getWindow();
            currentStage.close();
        }catch(IOException ioe){
            ShowMessage.showAlertSimple(
                "Error", 
                "Error al abrir la ventana", 
                Alert.AlertType.ERROR
            );
        }
    }
    
    private void configurarTabla(){
        this.ctMatricula.setCellValueFactory(new PropertyValueFactory("matricula"));
        this.ctNombre.setCellValueFactory(new PropertyValueFactory("nombre"));
        this.ctApellidoPat.setCellValueFactory(new PropertyValueFactory("apellidoPaterno"));
    }
    
    private void cargarAvances(){   
        
    }
}
