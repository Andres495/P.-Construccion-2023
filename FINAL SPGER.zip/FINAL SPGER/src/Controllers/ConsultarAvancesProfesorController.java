package Controllers;

import ConexionBD.ResultadoOperacion;
import DAO.AvancesDAO;
import POJO.Avance;
import POJO.Curso;
import Utils.ShowMessage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Date;
import java.time.LocalDate;
import java.time.Instant;
import java.time.ZoneId;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableArray;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;


public class ConsultarAvancesProfesorController implements Initializable {

    @FXML
    private TableView<Avance> tvAvances;
    @FXML
    private TableColumn<Avance, String> ctNumAvance;
    @FXML
    private TableColumn<Avance, String> ctFechaCierre;
    @FXML
    private TableColumn<Avance, String> ctFechaInicio;
    @FXML
    private TextArea tfDescripcion;
    @FXML
    private TextField tfNumAvance;
    @FXML
    private ImageView ivArchivo;
    @FXML
    private Button btAceptar;
    @FXML
    private DatePicker dpInicio;
    @FXML
    private DatePicker dpCierra;
    @FXML
    private Button btCrear;
    @FXML
    private Button btModificar;
    @FXML
    private Button btEliminar;
    @FXML
    private Button btCalificar;
    @FXML
    private Button btCancelar;
    @FXML
    private Button btAdjuntar;
    @FXML
    private Label lbNombreArchivo;
    
    private ObservableList<Avance> listaAvances;
    public static Curso cursoActual = null;    
    private boolean esEdicion = false;
    private boolean esCreacion = false;
    private File archivoPDF;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.configurarTabla();
        this.cargarAvances();
        this.tvAvances.setOnMouseClicked(event -> {
            if (event.getClickCount() == 1) {
                Avance selectedAvance = this.tvAvances.getSelectionModel().getSelectedItem();
                if (selectedAvance!= null) {
                    // Convertir el objeto java.util.Date a java.time.LocalDate
                    LocalDate fecha = LocalDate.parse(String.valueOf(selectedAvance.getFechaInicio()));
                    this.dpInicio.setValue(fecha);
                    fecha = LocalDate.parse(String.valueOf(selectedAvance.getFechaCierre()));
                    this.dpCierra.setValue(fecha);
                    
                    this.tfDescripcion.setText(selectedAvance.getDescripcion());
                    this.tfNumAvance.setText(String.valueOf(selectedAvance.getNumAvance()));
                    this.lbNombreArchivo.setText(selectedAvance.getNombreArchivo());
                }
            }
        });
        this.dpInicio.setEditable(false);
        this.dpCierra.setEditable(false);
    }      
    
    @FXML
    private void clicVolver(ActionEvent event) {
        try{
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/Views/PrincipalAcademico.fxml"));
            Parent root = loader.load();
        
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

            // Cerrar la ventana actual si es necesario
            Stage currentStage = (Stage)this.tvAvances.getScene().getWindow();
            currentStage.close();
        }catch(IOException ioe){
            ShowMessage.showAlertSimple(
                "Error", 
                "Error al abrir la ventana", 
                Alert.AlertType.ERROR
            );
        }
    }
    
    @FXML
    private void clicCrear(ActionEvent event) {
        this.esCreacion = !this.esCreacion;
        
        if(this.esCreacion == false){
            this.tvAvances.setMouseTransparent(false);  //Habilita la selección de la tabla
            this.btCrear.setDisable(false);             //Habilita los botones crear, modificar y eliminar
            this.btModificar.setDisable(false);         //Para evitar conflicto
            this.btEliminar.setDisable(false);
            this.dpInicio.setEditable(false);           //Deshabilita los DatePicker y el TextField
            this.dpCierra.setEditable(false);
            this.tfDescripcion.setEditable(false);
            this.tfNumAvance.setEditable(false);
            this.btAdjuntar.setVisible(false);          //Deshabilita el botón adjuntar, modificar y cancelar
            this.btAdjuntar.setDisable(true);
            this.btAceptar.setVisible(false);
            this.btAceptar.setDisable(true);
            this.btCancelar.setVisible(false);
            this.btCancelar.setDisable(true);
        }else if(this.esCreacion == true){
            this.tvAvances.setMouseTransparent(true);  //Deshabilita la selección de la tabla
            this.btCrear.setDisable(true);             //Deshabilita los botones crear, modificar y eliminar
            this.btModificar.setDisable(true);         //Para evitar conflicto
            this.btEliminar.setDisable(true);
            this.dpInicio.setEditable(true);           //Habilita los DatePicker y el TextField
            this.dpCierra.setEditable(true);
            this.tfDescripcion.setEditable(true);
            this.tfNumAvance.setEditable(true);
            this.btAdjuntar.setVisible(true);          //Habilita el botón adjuntar, modificar y cancelar
            this.btAdjuntar.setDisable(false);
            this.btAceptar.setVisible(true);
            this.btAceptar.setDisable(false);
            this.btCancelar.setVisible(true);
            this.btCancelar.setDisable(false);
        }     
    }
    
    @FXML
    private void clicModificar1(ActionEvent event) {
        Avance avanceDelete = this.verificarAvanceSelected();
        
        if(avanceDelete != null){
            this.esEdicion = !this.esEdicion;

            if(this.esEdicion == false){
                this.tvAvances.setMouseTransparent(false);  //Habilita la selección de la tabla
                this.btCrear.setDisable(false);             //Habilita los botones crear, modificar y eliminar
                this.btModificar.setDisable(false);         //Para evitar conflicto
                this.btEliminar.setDisable(false);
                this.dpInicio.setEditable(false);           //Deshabilita los DatePicker y el TextField
                this.dpCierra.setEditable(false);
                this.tfDescripcion.setEditable(false);
                this.tfNumAvance.setEditable(false);
                this.btAdjuntar.setVisible(false);          //Deshabilita el botón adjuntar, modificar y cancelar
                this.btAdjuntar.setDisable(true);
                this.btAceptar.setVisible(false);
                this.btAceptar.setDisable(true);
                this.btCancelar.setVisible(false);
                this.btCancelar.setDisable(true);
            }else if(this.esEdicion == true){
                this.tvAvances.setMouseTransparent(true);  //Deshabilita la selección de la tabla
                this.btCrear.setDisable(true);             //Deshabilita los botones crear, modificar y eliminar
                this.btModificar.setDisable(true);         //Para evitar conflicto
                this.btEliminar.setDisable(true);
                this.dpInicio.setEditable(true);           //Deshabilita los DatePicker y el TextField
                this.dpCierra.setEditable(true);
                this.tfDescripcion.setEditable(true);
                this.tfNumAvance.setEditable(true);
                this.btAdjuntar.setVisible(true);          //Deshabilita el botón adjuntar, modificar y cancelar
                this.btAdjuntar.setDisable(false);
                this.btAceptar.setVisible(true);
                this.btAceptar.setDisable(false);
                this.btCancelar.setVisible(true);
                this.btCancelar.setDisable(false);
            }     
        }else{
            ShowMessage.showAlertSimple(
                "Selección obligatoria", 
                "Debes seleccionar algún registro de la tabla para su modificación", 
                Alert.AlertType.WARNING
            );
        }
    }
    
    @FXML
    private void clicAdjuntar(ActionEvent event) {
        FileChooser dialogoPDF = new FileChooser();
        dialogoPDF.setTitle("Seleccione un PDF");
        FileChooser.ExtensionFilter filtroPDF = new FileChooser.ExtensionFilter("Archivos PDF (*.pdf)", "*.pdf");
        dialogoPDF.getExtensionFilters().add(filtroPDF);
        Stage escenarioActual = (Stage) this.btAdjuntar.getScene().getWindow();
        File nuevoArchivoPDF = dialogoPDF.showOpenDialog(escenarioActual);

        if (nuevoArchivoPDF != null && nuevoArchivoPDF.exists()) {
            // Eliminar el archivo PDF anterior si existe
            if (archivoPDF != null && archivoPDF.exists()) {
                archivoPDF.delete();
            }

            // Asignar el nuevo archivo PDF adjuntado
            archivoPDF = nuevoArchivoPDF;

            try {
                // Limpiar el paneContenedor antes de mostrar el nuevo archivo adjuntado
                this.ivArchivo.setImage(null);

                // Mostrar el icono del pdf y el nombre del archivo
                String rutaImagen = "/Imagenes/PDFIcono.png"; // Reemplaza con la ruta correcta del icono del PDF
                this.ivArchivo = new ImageView(rutaImagen);

                Label labelNombreArchivo = new Label(archivoPDF.getName());
                this.lbNombreArchivo.setText(archivoPDF.getName());
                //labelNombreArchivo.setGraphic(this.ivArchivo);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void clicDescargar(MouseEvent event) {
    }

    @FXML
    private void clicEliminar(ActionEvent event) {
        Avance avanceDelete = this.verificarAvanceSelected();
        
        if(avanceDelete != null){
            boolean eliminar = ShowMessage.showConfirmationDialog(
                    "Eliminar avance", 
                    "¿Deseas eliminar la información del avance "+avanceDelete.toString()+"?"
            );
            if(eliminar == true){
                try {
                    ResultadoOperacion resultado = AvancesDAO.deleteAvance(avanceDelete.getIdAvance());
                    if(!resultado.isError()){
                        ShowMessage.showAlertSimple(
                            "Registro eliminado", 
                            resultado.getMensaje(), 
                            Alert.AlertType.INFORMATION
                        );
                        this.cargarAvances();
                    }else{
                        ShowMessage.showAlertSimple(
                            "Operación incorrecta", 
                            resultado.getMensaje(), 
                            Alert.AlertType.ERROR
                        );
                    }
                } catch (SQLException e) {
                    ShowMessage.showAlertSimple(
                        "ERROR", 
                        e.getMessage(), 
                        Alert.AlertType.ERROR
                    );
                }
            }
        }else{
            ShowMessage.showAlertSimple(
                "Selección obligatoria", 
                "Debes seleccionar algún registro de la tabla para su eliminación", 
                Alert.AlertType.WARNING
            );
        }
        this.cargarAvances();
    }
    
    @FXML
    private void clicAceptar(ActionEvent event) {
        if(this.esEdicion == true){
            modificarActividad();
        }
        if(this.esCreacion == true){
            crearActividad();
        }
        this.cargarAvances();
    }
    
    private void crearActividad(){
        if(this.validarDatos(this.tfNumAvance.getText(), AvancesDAO.cursoActual) == true){   //Busca la existencia de datos faltantes o incorrectos
            //SE CREA EL TRANSFEROBJECT
            Avance avanceNew = new Avance();
            avanceNew.setNumAvance(Integer.parseInt(this.tfNumAvance.getText()));
            avanceNew.setDescripcion(this.tfDescripcion.getText());
                java.sql.Date fecha = java.sql.Date.valueOf(LocalDate.now());
            avanceNew.setFechaCreacion(fecha);
                fecha = java.sql.Date.valueOf(this.dpInicio.getValue());
            avanceNew.setFechaInicio(fecha);
                fecha = java.sql.Date.valueOf(this.dpCierra.getValue());
            avanceNew.setFechaCierre(fecha);
            avanceNew.setCurso(AvancesDAO.cursoActual.getIdcurso());
            avanceNew.setNombreArchivo(this.lbNombreArchivo.getText());
            
            
            try {
                ResultadoOperacion resultadoEdit = AvancesDAO.createAvance(avanceNew, this.cursoActual);
                if(resultadoEdit.getFilasAfectadas() <= 0){
                    ShowMessage.showAlertSimple(
                        "Error", 
                        "Error de conexión", 
                        Alert.AlertType.ERROR
                    );
                }else{
                    this.tvAvances.setMouseTransparent(false);  //Habilita la selección de la tabla
                    this.btCrear.setDisable(false);             //Habilita los botones crear, modificar y eliminar
                    this.btModificar.setDisable(false);         //Para evitar conflicto
                    this.btEliminar.setDisable(false);
                    this.dpInicio.setEditable(false);           //Deshabilita los DatePicker y el TextField
                    this.dpCierra.setEditable(false);
                    this.tfDescripcion.setEditable(false);
                    this.tfNumAvance.setEditable(false);
                    this.btAdjuntar.setVisible(false);          //Deshabilita el botón adjuntar, modificar y cancelar
                    this.btAdjuntar.setDisable(true);
                    this.btAceptar.setVisible(false);
                    this.btAceptar.setDisable(true);
                    this.btCancelar.setVisible(false);
                    this.btCancelar.setDisable(true);
                }
            } catch (SQLException ex) {
                ShowMessage.showAlertSimple(
                    "Error", 
                    "Error de conexión", 
                    Alert.AlertType.ERROR
                );
            }
        }else{
            ShowMessage.showAlertSimple(
                "Error", 
                "Ha ingresado datos incorrectos", 
                Alert.AlertType.ERROR
            );
        }
    }
    
    private void modificarActividad(){
        if(this.validarDatos(this.tfNumAvance.getText(), cursoActual) == true){   //Busca la existencia de datos faltantes o incorrectos
            //SE CREA EL TRANSFEROBJECT
            Avance avanceEdit = new Avance();
            avanceEdit.setIdAvance(this.verificarAvanceSelected().getIdAvance());
                java.sql.Date date = java.sql.Date.valueOf(this.dpInicio.getValue());
            avanceEdit.setFechaInicio(date);
                date = java.sql.Date.valueOf(this.dpCierra.getValue());
            avanceEdit.setFechaCierre(date);
            date = null;
            avanceEdit.setDescripcion(this.tfDescripcion.getText());
            avanceEdit.setNumAvance(Integer.parseInt(this.tfNumAvance.getText()));
            avanceEdit.setNombreArchivo(this.lbNombreArchivo.getText());
            
            try {
                ResultadoOperacion resultadoNew = AvancesDAO.updateAvance(avanceEdit);
                if(resultadoNew.getFilasAfectadas() <= 0){
                    ShowMessage.showAlertSimple(
                        "Error", 
                        "Error de conexión", 
                        Alert.AlertType.ERROR
                    );
                }else{
                    this.tvAvances.setMouseTransparent(false);  //Habilita la selección de la tabla
                    this.btCrear.setDisable(false);             //Habilita los botones crear, modificar y eliminar
                    this.btModificar.setDisable(false);         //Para evitar conflicto
                    this.btEliminar.setDisable(false);
                    this.dpInicio.setEditable(false);           //Deshabilita los DatePicker y el TextField
                    this.dpCierra.setEditable(false);
                    this.tfDescripcion.setEditable(false);
                    this.tfNumAvance.setEditable(false);
                    this.btAdjuntar.setVisible(false);          //Deshabilita el botón adjuntar, modificar y cancelar
                    this.btAdjuntar.setDisable(true);
                    this.btAceptar.setVisible(false);
                    this.btAceptar.setDisable(true);
                    this.btCancelar.setVisible(false);
                    this.btCancelar.setDisable(true);
                }
            } catch (SQLException ex) {
                ShowMessage.showAlertSimple(
                    "Error", 
                    "Error de conexión", 
                    Alert.AlertType.ERROR
                );
            }
        }else{
            ShowMessage.showAlertSimple(
                "Error", 
                "Ha ingresado datos incorrectos", 
                Alert.AlertType.ERROR
            );
        }
    }
    
    @FXML
    private void clicCancelar(ActionEvent event) {
        this.tvAvances.setMouseTransparent(false);  //Habilita la selección de la tabla
        this.btCrear.setDisable(false);             //Habilita los botones crear, modificar y eliminar
        this.btModificar.setDisable(false);         //Para evitar conflicto
        this.btEliminar.setDisable(false);
        this.dpInicio.setEditable(false);           //Deshabilita los DatePicker y el TextField
        this.dpCierra.setEditable(false);
        this.tfDescripcion.setEditable(false);
        this.tfDescripcion.setText("Descripción de avance");
        this.btAdjuntar.setVisible(false);          //Deshabilita el botón adjuntar, modificar y cancelar
        this.btAdjuntar.setDisable(true);
        this.btAceptar.setVisible(false);
        this.btAceptar.setDisable(true);
        this.btCancelar.setVisible(false);
        this.btCancelar.setDisable(true);
        this.cargarAvances();
    }
    
    @FXML
    private void clicCalificar(ActionEvent event) {
        try{
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/Views/CalificarAvances.fxml"));
            Parent root = loader.load();
        
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

            // Cerrar la ventana actual si es necesario
            Stage currentStage = (Stage)this.tvAvances.getScene().getWindow();
            currentStage.close();
        }catch(IOException ioe){
            ShowMessage.showAlertSimple(
                "Error", 
                "Error al abrir la ventana", 
                Alert.AlertType.ERROR
            );
        }
    }
    
    private boolean validarDatos(String numAvance, Curso cursoAct){
        try {
            int numeroEntero = Integer.parseInt(numAvance);
            if(numeroEntero <= 0){
                return false;
            }
            if(AvancesDAO.validarNumAvance(numeroEntero, cursoAct) != true){
                return false;
            }
            
            if(this.tfDescripcion.getText().length() <= 0){
                return false;
            }
            if(dpInicio.getValue()==null || dpCierra.getValue()==null ){
                return false;
            }
            if(dpCierra.getValue().isBefore(dpInicio.getValue())){
                return false;
            }
        } catch (NumberFormatException e) {
            return false;
            
        }catch (SQLException ex) {
            ShowMessage.showAlertSimple(
                "Error", 
                "Error en la conexión", 
                Alert.AlertType.ERROR
            );
        }finally{
            return true;
        }
    }
    
    private void configurarTabla(){
        this.ctNumAvance.setCellValueFactory(new PropertyValueFactory("numAvance"));
        this.ctFechaInicio.setCellValueFactory(new PropertyValueFactory("fechaInicio"));
        this.ctFechaCierre.setCellValueFactory(new PropertyValueFactory("fechaCierre"));
    }
    
    private void cargarAvances(){   
        this.listaAvances = FXCollections.observableArrayList(AvancesDAO.avancesConsultadas);
        tvAvances.setItems(this.listaAvances);
    }
    
    private Avance verificarAvanceSelected(){
        int selectedRow = this.tvAvances.getSelectionModel().getSelectedIndex();
        return (selectedRow >= 0) ? this.listaAvances.get(selectedRow) : null ;
    }
    
    public static void setCursoActual(Curso curso){
        cursoActual = curso;
    }
}

    
