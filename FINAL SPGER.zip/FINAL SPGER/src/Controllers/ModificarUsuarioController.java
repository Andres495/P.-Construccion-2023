/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controllers;

import ConexionBD.ResultadoOperacion;
import DAO.UsuarioDAO;
import POJO.Usuario;
import Utils.ShowMessage;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.function.UnaryOperator;
import java.util.regex.Pattern;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Carmona
 */
public class ModificarUsuarioController implements Initializable {

    @FXML
    private Label lbTituloFormulario;
    @FXML
    private TextField tfMatricula;
    @FXML
    private TextField tfNombres;
    @FXML
    private TextField tfApellidoPaterno;
    @FXML
    private TextField tfApellidoMaterno;
    @FXML
    private TextField tfUsername;
    @FXML
    private Button btnCancelarRegistro;
    @FXML
    private Button btnGuardarCambiosText;
    @FXML
    private PasswordField tfPassword;
    
    private Usuario usuarioEditable;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        configurarTextFieldombre();
        configurarTextFielApellidoP();
        configurarTextFielApellidoM();
        configurarTfMatricula();
    }    

    @FXML
    private void btnCancelarRegistro(ActionEvent event) {
        try {
            ShowMessage.showAlertSimple(
                "Registro",
                "Registro cancelado",
                Alert.AlertType.INFORMATION
            );
            try{
                FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/Views/GestionUsuarios.fxml"));
                Parent root = loader.load();

                Stage stage = new Stage();
                stage.setScene(new Scene(root));
                stage.show();

                // Cerrar la ventana actual si es necesario
                Stage currentStage = (Stage)this.btnCancelarRegistro.getScene().getWindow();
                currentStage.close();
            }catch(IOException ioe){
                ShowMessage.showAlertSimple(
                    "Error", 
                    "Error al sesión", 
                    Alert.AlertType.ERROR
                );
            }
        } catch (Exception e) {   
        }
    }

    @FXML
    private void btnGuardarCambios(ActionEvent event) {
        try {
            int matricula = Integer.parseInt(tfMatricula.getText());
            String nombre = tfNombres.getText();
            String apellidoPaterno = tfApellidoPaterno.getText();
            String apellidoMaterno = tfApellidoMaterno.getText();
            String usuario = tfUsername.getText();
            String contraseña = tfPassword.getText();
            usuarioEditable.setMatricula(matricula);
            usuarioEditable.setNombre(nombre);
            usuarioEditable.setApellidoPaterno(apellidoPaterno);
            usuarioEditable.setApellidoMaterno(apellidoMaterno);
            usuarioEditable.setNombreUsuario(usuario);
            usuarioEditable.setPassword(contraseña);
            guardarEdicion(usuarioEditable);
            cerrarVentana();
        } catch (NumberFormatException n){
            
        }
    }
    
    public void iniciarEdicion(Usuario usuario){
        this.usuarioEditable = usuario;
        if (usuario != null) {
            iniciarDatos();
        }
    }
    
    private void iniciarDatos(){
        tfMatricula.setText(String.valueOf(usuarioEditable.getMatricula()));
        tfNombres.setText(usuarioEditable.getNombre());
        tfApellidoPaterno.setText(usuarioEditable.getApellidoPaterno());
        tfApellidoMaterno.setText(usuarioEditable.getApellidoMaterno());
        tfUsername.setText(usuarioEditable.getNombreUsuario());
        tfPassword.setText(usuarioEditable.getPassword());
    }
    
    private void guardarEdicion(Usuario usuarioEditado){
        try {
            ResultadoOperacion resultado = UsuarioDAO
                    .guardarEdicion(usuarioEditado);
            if (!resultado.isError()) {
                ShowMessage.showAlertSimple("Mensaje", 
                        "Usuario modificado", 
                        Alert.AlertType.INFORMATION);
                abrirGestion();
            }
        } catch (NullPointerException e) {
            ShowMessage.showAlertSimple("Error", 
                    "Faltan datos",
                    Alert.AlertType.WARNING);
        } catch (SQLException s){
            s.printStackTrace();
        }
    }
    
    private void cerrarVentana(){
        Stage escenario = (Stage) tfNombres.getScene().getWindow();
        escenario.close();
    }
    
    private void abrirGestion(){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Views/GestionUsuarios.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void configurarTextFieldombre(){
        Pattern pattern = Pattern.compile("[a-zA-Z]*");
        
        UnaryOperator<TextFormatter.Change> filter = change -> {
            String newText = change.getControlNewText();
            if (pattern.matcher(newText).matches()) {
                return change; // Aceptar cambios válidos (solo letras)
            }
            return null; // Rechazar cambios inválidos
        };
        
        TextFormatter<String> textFormatter = new TextFormatter<>(filter);
        tfNombres.setTextFormatter(textFormatter);
    }
    
    private void configurarTextFielApellidoP(){
        Pattern pattern = Pattern.compile("[a-zA-Z]*");
        
        UnaryOperator<TextFormatter.Change> filter = change -> {
            String newText = change.getControlNewText();
            if (pattern.matcher(newText).matches()) {
                return change; // Aceptar cambios válidos (solo letras)
            }
            return null; // Rechazar cambios inválidos
        };
        
        TextFormatter<String> textFormatter = new TextFormatter<>(filter);
        tfApellidoPaterno.setTextFormatter(textFormatter);
    }
    
    private void configurarTextFielApellidoM(){
        Pattern pattern = Pattern.compile("[a-zA-Z]*");
        
        UnaryOperator<TextFormatter.Change> filter = change -> {
            String newText = change.getControlNewText();
            if (pattern.matcher(newText).matches()) {
                return change; // Aceptar cambios válidos (solo letras)
            }
            return null; // Rechazar cambios inválidos
        };
        
        TextFormatter<String> textFormatter = new TextFormatter<>(filter);
        tfApellidoMaterno.setTextFormatter(textFormatter);
    }
    
    private void configurarTfMatricula(){
        TextFormatter<String> textFormatter = new TextFormatter<>(change -> {
        String newText = change.getControlNewText();
        if (newText.matches("\\d{0,8}")) {
            return change; // Aceptar cambios válidos de máximo 8 caracteres numéricos
        }
        return null; // Rechazar cambios inválidos
        });
        tfMatricula.setTextFormatter(textFormatter);
    }
}
