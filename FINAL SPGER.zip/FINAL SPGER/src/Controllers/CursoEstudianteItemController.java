/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controllers;

import POJO.Curso;
import Utils.ShowMessage;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Carmona
 */
public class CursoEstudianteItemController implements Initializable {

    @FXML
    private Label lbNombreCurso;
    @FXML
    private Label lbPeriodo;
    
    private Curso curso;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void btnConsultarActividades(ActionEvent event) {
        irActividadesCurso();
    }

    @FXML
    private void btnConsultarAvances(ActionEvent event) {
        
    }
    
    public void ponerDatos(Curso curso){
        lbNombreCurso.setText(curso.getNombre());
        lbPeriodo.setText("Periodo: " + curso.getPeriodo());
        this.curso = curso;
    }
    
    private void irActividadesCurso(){
        try {
            FXMLLoader loader = new FXMLLoader(getClass()
                    .getResource("/Views/ActividadesEstudiante.fxml"));
            Parent root = loader.load();
            Scene escena = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(escena);
            stage.show();
            
            ActividadesEstudianteController controlador = loader.getController();
            controlador.ponerDatos(curso);
            
            cerrarVentana();
        } catch (Exception e) {
            ShowMessage.showAlertSimple("Error",
                    "No se puede mostrar la ventana",
                    Alert.AlertType.ERROR);
            e.printStackTrace();
        }
    }
    
    private void cerrarVentana(){
        Stage stageActual = (Stage)lbPeriodo.getScene().getWindow();
        stageActual.close();
    }

    private void btnGetId(ActionEvent event) {
        System.out.println(curso.getIdcurso());
    }
    
}
