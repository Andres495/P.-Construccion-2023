/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controllers;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import Utils.ShowMessage;
import POJO.RolSistema;
import POJO.Usuario;
import DAO.RolSistemaDAO;
import DAO.UsuarioDAO;
import ConexionBD.ResultadoOperacion;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.function.UnaryOperator;
import java.util.regex.Pattern;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextFormatter;

/**
 * FXML Controller class
 *
 * @author lecap
 */
public class FormularioUsuarioController implements Initializable {

    @FXML
    private Label lbTituloFormulario;
    @FXML
    private TextField tfMatricula;
    @FXML
    private TextField tfNombres;
    @FXML
    private TextField tfApellidoPaterno;
    @FXML
    private TextField tfApellidoMaterno;
    @FXML
    private TextField tfUsername;
    @FXML
    private ComboBox cbTipoUsuario = new ComboBox();
    @FXML
    private PasswordField tfPassword;
    @FXML
    private Button btnRegistrarUsuarioTexto;
    @FXML
    private Button btnCancelarRegistro;
    @FXML
    private Label lbTipoUsuario;
    
    private Usuario usuarioEdicion;
    private ObservableList<RolSistema> listaRolSistema;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        cargarListaRolesSistema(); 
        configurarTextFieldombre();
        configurarTextFielApellidoP();
        configurarTextFielApellidoM();
        configurarTfMatricula();
        cbTipoUsuario.getSelectionModel().selectFirst();
     }
    
    private void cargarListaRolesSistema(){
        listaRolSistema = FXCollections.observableArrayList();
        try {
            ArrayList<RolSistema> rolSistemaDB = RolSistemaDAO
                    .obtenerRolesSistema();
            listaRolSistema.addAll(rolSistemaDB);
            cbTipoUsuario.setItems(listaRolSistema);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void configurarTextFieldombre(){
        Pattern pattern = Pattern.compile("[a-zA-Z]*");
        
        UnaryOperator<TextFormatter.Change> filter = change -> {
            String newText = change.getControlNewText();
            if (pattern.matcher(newText).matches()) {
                return change; // Aceptar cambios válidos (solo letras)
            }
            return null; // Rechazar cambios inválidos
        };
        
        TextFormatter<String> textFormatter = new TextFormatter<>(filter);
        tfNombres.setTextFormatter(textFormatter);
    }
    
    private void configurarTextFielApellidoP(){
        Pattern pattern = Pattern.compile("[a-zA-Z]*");
        
        UnaryOperator<TextFormatter.Change> filter = change -> {
            String newText = change.getControlNewText();
            if (pattern.matcher(newText).matches()) {
                return change; // Aceptar cambios válidos (solo letras)
            }
            return null; // Rechazar cambios inválidos
        };
        
        TextFormatter<String> textFormatter = new TextFormatter<>(filter);
        tfApellidoPaterno.setTextFormatter(textFormatter);
    }
    
    private void configurarTextFielApellidoM(){
        Pattern pattern = Pattern.compile("[a-zA-Z]*");
        
        UnaryOperator<TextFormatter.Change> filter = change -> {
            String newText = change.getControlNewText();
            if (pattern.matcher(newText).matches()) {
                return change; // Aceptar cambios válidos (solo letras)
            }
            return null; // Rechazar cambios inválidos
        };
        
        TextFormatter<String> textFormatter = new TextFormatter<>(filter);
        tfApellidoMaterno.setTextFormatter(textFormatter);
    }
    
    private void configurarTfMatricula(){
        TextFormatter<String> textFormatter = new TextFormatter<>(change -> {
        String newText = change.getControlNewText();
        if (newText.matches("\\d{0,8}")) {
            return change; // Aceptar cambios válidos de máximo 8 caracteres numéricos
        }
        return null; // Rechazar cambios inválidos
        });
        tfMatricula.setTextFormatter(textFormatter);
    }
  
    @FXML
    private void btnCancelarRegistro(ActionEvent event) {
        try {
            ShowMessage.showAlertSimple("Registro",
                        "Registro cancelado",
                        Alert.AlertType.INFORMATION);
                cerrarVentana();
                abrirGestion();
        } catch (Exception e) {   
        }
    }

    @FXML
    private void btnRegistrarUsuario(ActionEvent event) {
        try {
            int matricula = Integer.parseInt(tfMatricula.getText());
            String nombre = tfNombres.getText();
            String apellidoPaterno = tfApellidoPaterno.getText();
            String apellidoMaterno = tfApellidoMaterno.getText();
            String username = tfUsername.getText();
            String password = tfPassword.getText();
            RolSistema idRolSistema = (RolSistema)cbTipoUsuario.getValue();
            int tipoUsuario = idRolSistema.getIdRolSistema();
            //Crear nuevo usuario 
            Usuario nuevoUsuario = new Usuario();
            nuevoUsuario.setMatricula(matricula);
            nuevoUsuario.setNombre(nombre);
            nuevoUsuario.setApellidoPaterno(apellidoPaterno);
            nuevoUsuario.setApellidoMaterno(apellidoMaterno);
            nuevoUsuario.setNombreUsuario(username);
            nuevoUsuario.setPassword(password);
            nuevoUsuario.setIdRolSistema(tipoUsuario);
            guardarNuevoUsuario(nuevoUsuario);
        } catch (NullPointerException e) {
            ShowMessage.showAlertSimple("Campos faltantes",
                    "Faltan campos en el formulario", Alert.AlertType.WARNING);
        }catch(NumberFormatException n){
            
        }    
    }
    
    private void guardarNuevoUsuario(Usuario nuevoUsuario){
        try {
            ResultadoOperacion resultado = UsuarioDAO.registrarUsuario(nuevoUsuario);
            if (!resultado.isError()) {
                try {
                    ShowMessage.showAlertSimple("Registro", "Usuario registrado"
                        , Alert.AlertType.INFORMATION);
                    cerrarVentana();
                    abrirGestion();
                } catch (Exception e) {
                    e.printStackTrace();
                } 
            }else{
                ShowMessage.showAlertSimple("ERROR", "Campos faltantes",
                        Alert.AlertType.WARNING);          
            }
        } catch (SQLIntegrityConstraintViolationException e) {
            ShowMessage.showAlertSimple("ERROR", "El usuario ya existe",
                    Alert.AlertType.ERROR); 
        } catch (SQLException ex){
            
        }
    }
    
    private void cerrarVentana(){
        Stage escenario = (Stage) tfNombres.getScene().getWindow();
        escenario.close();
    }
    
    private void abrirGestion(){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Views/GestionUsuarios.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
