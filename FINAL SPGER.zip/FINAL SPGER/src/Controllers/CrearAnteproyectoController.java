/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controllers;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import POJO.LGAC;
import POJO.Usuario;
import DAO.LGACDAO;
import DAO.UsuarioDAO;
import POJO.Anteproyecto;
import ConexionBD.ResultadoOperacion;
import Utils.ShowMessage;
import DAO.AnteproyectoDAO;

/**
 * FXML Controller class
 *
 * @author Carmona
 */
public class CrearAnteproyectoController implements Initializable {

    @FXML
    private TextField tfNombreAnteproyecto;
    @FXML
    private ComboBox cbLGACAnteproyecto = new ComboBox();
    @FXML
    private TextArea taLineaInvestigación;
    @FXML
    private ComboBox cbCoDirector = new ComboBox();
    @FXML
    private Pane paneContenedor;
    @FXML
    private Label lbNombreArchivo;
    private String nombreArchivo;
    ObservableList<LGAC> listaLGAC;
    ObservableList<Usuario> listaAcademicos;
    private File archivoPDF;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        cargarListaLGAC();
        cargarListaAcademicos();
        cbCoDirector.getSelectionModel().selectFirst();
        cbLGACAnteproyecto.getSelectionModel().selectFirst();
    }    

    @FXML
    private void btnAdjuntarPDF(ActionEvent event) {
        FileChooser dialogoPDF = new FileChooser();
        dialogoPDF.setTitle("Selecciona un PDF");
        FileChooser.ExtensionFilter filtroPDF = new FileChooser.ExtensionFilter("Archivos PDF (*.pdf)", "*.pdf");
        dialogoPDF.getExtensionFilters().add(filtroPDF);
        Stage escenarioActual = (Stage) tfNombreAnteproyecto.getScene().getWindow();
        File nuevoArchivoPDF = dialogoPDF.showOpenDialog(escenarioActual);

        if (nuevoArchivoPDF != null && nuevoArchivoPDF.exists()) {
            // Eliminar el archivo PDF anterior si existe
            if (archivoPDF != null && archivoPDF.exists()) {
            archivoPDF.delete();
            }

            // Asignar el nuevo archivo PDF adjuntado
            archivoPDF = nuevoArchivoPDF;

            try {
                // Limpiar el paneContenedor antes de mostrar el nuevo archivo adjuntado
                paneContenedor.getChildren().clear();

                // Mostrar el icono del pdf y el nombre del archivo
                String rutaImagen = "/Imagenes/PDFIcono.png"; // Reemplaza con la ruta correcta del icono del PDF
                ImageView vistaImagen = new ImageView(rutaImagen);
                vistaImagen.setFitWidth(100);
                vistaImagen.setFitHeight(100);

                Label labelNombreArchivo = new Label(archivoPDF.getName());
                this.nombreArchivo=archivoPDF.getName();
                labelNombreArchivo.setGraphic(vistaImagen);

                paneContenedor.getChildren().addAll(vistaImagen, labelNombreArchivo);
            } catch (Exception e) {
            e.printStackTrace();
            }
        }
    }
    
    /*
    Estados de un anteproyecto
    1 = creado
    2 = postulado
    3 = aceptado
    4 = rechazado
    */
    
    private int guardarAnteproyecto(Anteproyecto anteproyecto) throws SQLException {
        int idAnteproyecto = -1; // 
        try {
            ResultadoOperacion resultadoPostularAnteproyecto = AnteproyectoDAO
                    .crearAnteproyecto(anteproyecto);
            if (!resultadoPostularAnteproyecto.isError()) {
                idAnteproyecto = resultadoPostularAnteproyecto.getFilasAfectadas();
                ShowMessage.showAlertSimple("Mensaje", "Anteproyecto postulado"
                        , Alert.AlertType.INFORMATION);
            } else {
                ShowMessage.showAlertSimple("Error", "Campos faltantes"
                        , Alert.AlertType.ERROR);
        }
        } catch (SQLException e) {
            ShowMessage.showAlertSimple("Error"
                    , "Error de conexión", Alert.AlertType.ERROR);
        }
        return idAnteproyecto;
    }
    

    private void cargarListaLGAC(){
        listaLGAC = FXCollections.observableArrayList();
        try {
            ArrayList<LGAC> LGACBD = LGACDAO.obtenerLGAC();
            listaLGAC.addAll(LGACBD);
            cbLGACAnteproyecto.setItems(listaLGAC);         
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void cargarListaAcademicos(){
        listaAcademicos = FXCollections.observableArrayList();
        try {
            ArrayList<Usuario> academicos = UsuarioDAO.obtenerUsuariosAcademicos();
            listaAcademicos.addAll(academicos);
            cbCoDirector.setItems(listaAcademicos);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void btnCancelar(ActionEvent event) throws IOException{
        ShowMessage.showAlertSimple("Aviso",
                "Creación de anteproyecto cancelada",
                Alert.AlertType.INFORMATION);
        Node source = (Node) event.getSource();
        Stage stageActual = (Stage) source.getScene().getWindow();
        stageActual.close();
        
    }

    private void getidusuarioactual(ActionEvent event) {
        Usuario usuarioActual = UsuarioDAO.getUsuarioActual();
        System.out.println(usuarioActual.getIdUsuario());
    }

    @FXML
    private void btnCrear(ActionEvent event) {
        try {
            byte[] contenidoArchivo = null;
            if (archivoPDF != null && archivoPDF.exists()) {
                try (FileInputStream fis = new FileInputStream(archivoPDF);
                    ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = fis.read(buffer)) != -1) {
                        bos.write(buffer, 0, bytesRead);
                    }
                    contenidoArchivo = bos.toByteArray();
                } catch (IOException e) {
                    e.printStackTrace();
                }   
            }
            Usuario usuarioActual = UsuarioDAO.getUsuarioActual();
            String nombreAnteproyecto = tfNombreAnteproyecto.getText();
            String lineaInvestigacion = taLineaInvestigación.getText();
            int estado = 1;
            LGAC idlgac = (LGAC)cbLGACAnteproyecto.getValue();
            int lgacSeleccionada = idlgac.getIdLGAC();
            Usuario codirector = (Usuario)cbCoDirector.getValue();
            int codirectorSeleccionado = codirector.getIdUsuario();
            String nombreCodirector= codirector.getNombre();
            //Crear nuevo anteproyecto
            Anteproyecto nuevoAnteproyecto = new Anteproyecto();
            nuevoAnteproyecto.setNombre(nombreAnteproyecto);
            nuevoAnteproyecto.setLineaInvestigacion(lineaInvestigacion);
            nuevoAnteproyecto.setEstado(estado);
            nuevoAnteproyecto.setIdLGAC(lgacSeleccionada);
            nuevoAnteproyecto.setIdDirector(usuarioActual.getIdUsuario());
            nuevoAnteproyecto.setIdCoDirector(codirectorSeleccionado);
            nuevoAnteproyecto.setNombreCoDirector(nombreCodirector);
            nuevoAnteproyecto.setNombreDirector(usuarioActual.getNombre());
            nuevoAnteproyecto.setNombreArchivo(nombreArchivo);
            nuevoAnteproyecto.setArchivo(contenidoArchivo);
            int idAnteproyecto = guardarAnteproyecto(nuevoAnteproyecto);
            System.out.println(idAnteproyecto);
            cerrarVentana();
        } catch (NullPointerException e) {
            e.printStackTrace();
            ShowMessage.showAlertSimple("Error", "No se pudo guardar el anteproyecto", 
                    Alert.AlertType.ERROR);
        }catch (SQLException e){
            e.printStackTrace();
        }
    }
    
    private void cerrarVentana(){
        Stage escenario = (Stage) tfNombreAnteproyecto.getScene().getWindow();
        escenario.close();
    }
}
