/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utils;

/**
 *
 * @author Carmona
 */
public class CursoHolder {
    private static int cursoID;

    public static int getCursoID() {
        return cursoID;
    }

    public static void setCursoID(int cursoID) {
        CursoHolder.cursoID = cursoID;
    }
}
