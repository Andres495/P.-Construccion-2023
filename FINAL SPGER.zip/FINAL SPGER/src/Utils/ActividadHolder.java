/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utils;

/**
 *
 * @author Carmona
 */
public class ActividadHolder {
    private static int actividadId;

    public static int getActividadId() {
        return actividadId;
    }

    public static void setActividadId(int actividadId) {
        ActividadHolder.actividadId = actividadId;
    }
    
    
}
