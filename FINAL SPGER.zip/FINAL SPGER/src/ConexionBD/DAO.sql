UPDATE avance SET numAvance = ?, descripcion = ?, fechaCreacion = ?, fechaInicio = ?, 
fechaCierre = ?, nombreArchivo = ?, archivo = ?
WHERE idavance = 1;

SELECT * FROM Avance INNER JOIN Curso ON Avance.curso = Curso.idCurso 
WHERE Curso.idcurso = 1 AND Avance.numAvance = 1;

SELECT * FROM Curso RIGHT JOIN UsuarioCurso ON Curso.idcurso = UsuarioCurso.idCurso 
LEFT JOIN Usuario ON Usuario.idusuario = UsuarioCurso.idUsuario; 

SELECT * FROM entregaavance RIGHT JOIN usuario ON entregaavance.idUsuario = usuario.idusuario 
WHERE usuario.idUsuario = 1;