USE proyecto;
/*--------------------------------------------ROLES DE SISTEMA--------------------------------------------*/
INSERT INTO `proyecto`.`rolsistema` (`rolSistema`) VALUES ('Administrador');
INSERT INTO `proyecto`.`rolsistema` (`rolSistema`) VALUES ('Academico');
INSERT INTO `proyecto`.`rolsistema` (`rolSistema`) VALUES ('Estudiante');

/*--------------------------------------------LGAC--------------------------------------------*/
INSERT INTO `proyecto`.`lgac` (`nombre`, `descripcion`) VALUES ('L1.Tecnología', 'Descripción');
INSERT INTO `proyecto`.`lgac` (`nombre`, `descripcion`) VALUES ('L2.Inovación', 'Descripción');

/*--------------------------------------------ESTUDIANTES--------------------------------------------*/
INSERT INTO `proyecto`.`usuario` (`matricula`, `nombre`, `apellidoPaterno`, `apellidoMaterno`, `username`, `password`, `rolSistema`) 
VALUES ('21013890', 'Rodolfo', 'Fernandez', 'Rodriguez', 'est1', 'est1', '3');
INSERT INTO `proyecto`.`usuario` (`matricula`, `nombre`, `apellidoPaterno`, `apellidoMaterno`, `username`, `password`, `rolSistema`) 
VALUES ('21013891', 'Andres', 'Arellano', 'García', 'est2', 'est2', '3');
INSERT INTO `proyecto`.`usuario` (`matricula`, `nombre`, `apellidoPaterno`, `apellidoMaterno`, `username`, `password`, `rolSistema`) 
VALUES ('21013892', 'Martin Emmanuel', 'Cruz', 'Carmona', 'est3', 'est3', '3');
INSERT INTO `proyecto`.`usuario` (`matricula`, `nombre`, `apellidoPaterno`, `apellidoMaterno`, `username`, `password`, `rolSistema`) 
VALUES ('21013893', 'Cesar', 'Basilio', 'Gómez', 'est4', 'est4', '3');

/*--------------------------------------------ACADEMICOS--------------------------------------------*/
INSERT INTO `proyecto`.`usuario` (`matricula`, `nombre`, `apellidoPaterno`, `apellidoMaterno`, `username`, `password`, `rolSistema`) 
VALUES ('21013894', 'Yamileth', 'Hernández', 'Martines', 'acad1', 'acad1', '2');
INSERT INTO `proyecto`.`usuario` (`matricula`, `nombre`, `apellidoPaterno`, `apellidoMaterno`, `username`, `password`, `rolSistema`) 
VALUES ('21013895', 'Karen', 'Cortez', 'Verdín', 'acad2', 'acad2', '2');
INSERT INTO `proyecto`.`usuario` (`matricula`, `nombre`, `apellidoPaterno`, `apellidoMaterno`, `username`, `password`, `rolSistema`) 
VALUES ('21013896', 'Ramón', 'Gómez', 'Romero', 'acad3', 'acad3', '2');

/*--------------------------------------------ADMINISTRADORES--------------------------------------------*/
INSERT INTO `proyecto`.`usuario` (`matricula`, `nombre`, `apellidoPaterno`, `apellidoMaterno`, `username`, `password`, `rolSistema`) 
VALUES ('21013897', 'Betsy', 'Rodríguez', 'Acosta', 'adm1', 'adm1', '1');
INSERT INTO `proyecto`.`usuario` (`matricula`, `nombre`, `apellidoPaterno`, `apellidoMaterno`, `username`, `password`, `rolSistema`) 
VALUES ('21013898', 'Marilú', 'Sugey', 'Gonzáles', 'adm2', 'adm2', '1');
INSERT INTO `proyecto`.`usuario` (`matricula`, `nombre`, `apellidoPaterno`, `apellidoMaterno`, `username`, `password`, `rolSistema`) 
VALUES ('21013899', 'Esmeralda', 'Cristal', 'Cortéz', 'adm3', 'adm3', '1');

/*--------------------------------------------EXPERIENCIAS EDUCATIVAS--------------------------------------------*/
INSERT INTO experienciaeducativa (NRC, nombre, creditos) 
VALUES (123, 'Proyecto Guiado', 10);
INSERT INTO experienciaeducativa (NRC, nombre, creditos) 
VALUES (456, 'Experiencia recepcional', 11);

/*--------------------------------------------CURSOS--------------------------------------------*/
INSERT INTO curso (periodo, nombre, experienciaEducativa, idProfesor)
VALUES ('2023-A', 'Curso 1 PG', 1, 5);
INSERT INTO curso (periodo, nombre, experienciaEducativa, idProfesor)
VALUES ('2023-B', 'Curso 2 PG', 1, 6);

INSERT INTO curso (periodo, nombre, experienciaEducativa, idProfesor)
VALUES ('2023-A', 'Curso 1 ER', 2, 6);
INSERT INTO curso (periodo, nombre, experienciaEducativa, idProfesor)
VALUES ('2023-B', 'Curso 2 ER', 2, 7);

/*--------------------------------------------ESTUDIANTES CURSOS--------------------------------------------*/
INSERT INTO usuariocurso (idUsuario, idCurso) VALUES(1, 1);
INSERT INTO usuariocurso (idUsuario, idCurso) VALUES(2, 1);
INSERT INTO usuariocurso (idUsuario, idCurso) VALUES(3, 1);
INSERT INTO usuariocurso (idUsuario, idCurso) VALUES(4, 1);
INSERT INTO usuariocurso (idUsuario, idCurso) VALUES(1, 2);
INSERT INTO usuariocurso (idUsuario, idCurso) VALUES(2, 2);
INSERT INTO usuariocurso (idUsuario, idCurso) VALUES(3, 2);
INSERT INTO usuariocurso (idUsuario, idCurso) VALUES(4, 2);

/*--------------------------------------------AVANCES--------------------------------------------*/
INSERT INTO Avance (numAvance, descripcion, fechaCreacion, fechaInicio, 
fechaCierre, curso, nombreArchivo, archivo) VALUES 
(1, 'Descripción del avance 1 como ejemplo', '2023-06-14', '2023-06-15', '2023-06-16', 1, NULL, NULL);
INSERT INTO Avance (numAvance, descripcion, fechaCreacion, fechaInicio, 
fechaCierre, curso, nombreArchivo, archivo) VALUES 
(2, 'Descripción del avance 2 como ejemplo', '2023-06-13', '2023-06-16', '2023-06-17', 1, NULL, NULL);
INSERT INTO Avance (numAvance, descripcion, fechaCreacion, fechaInicio, 
fechaCierre, curso, nombreArchivo, archivo) VALUES 
(3, 'Descripción del avance 3 como ejemplo', '2023-06-12', '2023-06-17', '2023-06-18', 1, NULL, NULL);
INSERT INTO Avance (numAvance, descripcion, fechaCreacion, fechaInicio, 
fechaCierre, curso, nombreArchivo, archivo) VALUES 
(4, 'Descripción del avance 4 como ejemplo', '2023-06-11', '2023-06-18', '2023-06-19', 1, NULL, NULL);

/*--------------------------------------------ENTREGAS AVANCES--------------------------------------------*/
INSERT INTO entregaavance (idavance, descripcion, idusuario, fechaEntrega, nombreArchivo, archivo)
VALUES (1, 'Descripción  de entrega de avance de ejemplo', 1, '2023-06-15', 'Nombre1', NULL);
INSERT INTO entregaavance (idavance, descripcion, idusuario, fechaEntrega, nombreArchivo, archivo)
VALUES (1, 'Descripción  de entrega de avance de ejemplo', 2, '2023-06-16', 'Nombre2', NULL);
INSERT INTO entregaavance (idavance, descripcion, idusuario, fechaEntrega, nombreArchivo, archivo)
VALUES (1, 'Descripción  de entrega de avance de ejemplo', 3, '2023-06-17', 'Nombre3', NULL);
INSERT INTO entregaavance (idavance, descripcion, idusuario, fechaEntrega, nombreArchivo, archivo)
VALUES (1, 'Descripción  de entrega de avance de ejemplo', 4, '2023-06-18', 'Nombre4', NULL);

/*--------------------------------------------ACTIVIDADES--------------------------------------------*/
INSERT INTO actividad (nombre, descripcion, valor, fechaInicio, 
fechaCierre, curso, nombreArchivo, archivo) VALUES 
('Nombre act 1', 'Descripción de la actividad 1 como ejemplo', 5, '2023-06-14', '2023-06-18', 1, 'Nombre1', NULL);
INSERT INTO actividad (nombre, descripcion, valor, fechaInicio, 
fechaCierre, curso, nombreArchivo, archivo) VALUES 
('Nombre act 2', 'Descripción de la actividad 2 como ejemplo', 5, '2023-06-15', '2023-06-18', 1, 'Nombre2', NULL);
INSERT INTO actividad (nombre, descripcion, valor, fechaInicio, 
fechaCierre, curso, nombreArchivo, archivo) VALUES 
('Nombre act 3', 'Descripción de la actividad 3 como ejemplo', 6, '2023-06-16', '2023-06-18', 1, 'Nombre3', NULL);
INSERT INTO actividad (nombre, descripcion, valor, fechaInicio, 
fechaCierre, curso, nombreArchivo, archivo) VALUES 
('Nombre act 4', 'Descripción de la actividad 4 como ejemplo', 3, '2023-06-17', '2023-06-18', 1, 'Nombre4', NULL);

/*--------------------------------------------ENTREGAS ACTIVIDADES--------------------------------------------*/
INSERT INTO entregaactividad (idactividad, descripcion, idUsuario, fechaEntrega, nombreArchivo, archivo)
VALUES (1, 'Descripción  de entrega de avance de ejemplo', 1, '2023-06-15', 'Nombre1', NULL);
INSERT INTO entregaactividad (idactividad, descripcion, idUsuario, fechaEntrega, nombreArchivo, archivo)
VALUES (1, 'Descripción  de entrega de avance de ejemplo', 2, '2023-06-16', 'Nombre2', NULL);
INSERT INTO entregaactividad (idactividad, descripcion, idUsuario, fechaEntrega, nombreArchivo, archivo)
VALUES (1, 'Descripción  de entrega de avance de ejemplo', 3, '2023-06-17', 'Nombre3', NULL);
INSERT INTO entregaactividad (idactividad, descripcion, idUsuario, fechaEntrega, nombreArchivo, archivo)
VALUES (1, 'Descripción  de entrega de avance de ejemplo', 4, '2023-06-18', 'Nombre4',  NULL);