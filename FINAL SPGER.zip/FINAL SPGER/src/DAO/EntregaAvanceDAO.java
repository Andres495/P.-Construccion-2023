package DAO;

import ConexionBD.ConexionBD;
import POJO.EntregaAvance;
import POJO.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class EntregaAvanceDAO {
    public static ArrayList<EntregaAvance> getEntregasAlumno(int idAlumno) throws SQLException{
        ArrayList<EntregaAvance> entregasEstudiantes = null;
        Connection conexionBD = ConexionBD.abrirConexionBD();
        
        if(conexionBD != null){
            try {
                String sqlQuery = "SELECT * FROM entregaavance INNER JOIN usuario ON "+
                                  "entregaavance.idUsuario = usuario.idusuario " + 
                                  "WHERE usuario.idUsuario = ?; ";
                PreparedStatement getAllUsers = conexionBD.prepareStatement(sqlQuery);
                getAllUsers.setInt(1, idAlumno);
                ResultSet result = getAllUsers.executeQuery();

                entregasEstudiantes = new ArrayList<>();
                while(result.next()){
                    EntregaAvance entrega = new EntregaAvance();
                       entrega.setIdEntregaAvance(result.getInt("identregaAvance"));
                       entrega.setIdAvance(result.getInt("idAvance"));
                       entrega.setDescripcion(result.getString("descripcion"));
                       entrega.setIdEstudiante(idAlumno);
                       entrega.setNombreEstudiante(result.getString("nombre"));
                    entregasEstudiantes.add(entrega);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally{
                conexionBD.close();
            }
        }else{
            
        }
        return entregasEstudiantes;
    }
}
