package appcontrolescolar.alumno;

import appcontrolescolar.interfaces.RespuestaFormulario;
import appcontrolescolar.modelo.dao.AlumnoDAO;
import appcontrolescolar.modelo.dao.CarreraDAO;
import appcontrolescolar.modelo.dao.FacultadDAO;
import appcontrolescolar.modelo.pojo.Alumno;
import appcontrolescolar.modelo.pojo.Carrera;
import appcontrolescolar.modelo.pojo.Facultad;
import appcontrolescolar.modelo.pojo.ResultadoOperacion;
import appcontrolescolar.util.Utilidades;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;


public class FXMLFormularioAlumnoController implements Initializable {

    @FXML
    private Label lbTitulo;
    @FXML
    private TextField tfMatricula;
    @FXML
    private TextField tfNombre;
    @FXML
    private TextField tfApellidoPaterno;
    @FXML
    private TextField tfFechaNacimiento;
    @FXML
    private TextField tfCorreo;
    @FXML
    private TextField tfApellidoMaterno;
    @FXML
    private ComboBox<Facultad> cbFacultad;
    @FXML
    private ComboBox<Carrera> cbCarrera;
    @FXML
    private ImageView ivFoto;
  
    private File archivoFoto;
    private ObservableList<Facultad> listaFacultades;
    private ObservableList<Carrera> listaCarreras;
    private RespuestaFormulario notificacion;
    private Alumno alumnoEdicion;
    private boolean esEdicion;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cargarListaFacultades();
      
        cbFacultad.valueProperty().addListener(new ChangeListener<Facultad>(){
            
            @Override
            public void changed(ObservableValue<? extends Facultad> observable, 
                    Facultad oldValue, Facultad newValue) {
                if(newValue != null){
                    cargarListaCarreras(newValue.getIdFacultad());
                }
            }
            
        });
    }
    
    public void inicializarValores(RespuestaFormulario notificacion, 
                                    Alumno alumnoEdicion){
        this.notificacion = notificacion;
        this.alumnoEdicion = alumnoEdicion;
        esEdicion = (alumnoEdicion != null); 
        if(esEdicion)
            cargarInformacionAlumnoEdicion();
    }
    
    private void cargarInformacionAlumnoEdicion(){
        lbTitulo.setText("Edición del alumno "+alumnoEdicion.getNombre());
        tfMatricula.setText(alumnoEdicion.getMatricula());
        tfMatricula.setEditable(false);
        tfNombre.setText(alumnoEdicion.getNombre());
        tfApellidoPaterno.setText(alumnoEdicion.getApellidoPaterno());
        tfApellidoMaterno.setText(alumnoEdicion.getApellidoMaterno());
        tfCorreo.setText(alumnoEdicion.getCorreo());
        tfFechaNacimiento.setText(alumnoEdicion.getFechaNacimiento());
        int posicionFacultad = obtenerPosicionFacultad(alumnoEdicion.getIdFacultad());
        cbFacultad.getSelectionModel().select(posicionFacultad);
        int posicionCarrera = obtenerPosicionCarrera(alumnoEdicion.getIdCarrera());
        cbCarrera.getSelectionModel().select(posicionCarrera);
        
        try {
            ByteArrayInputStream inputFoto = new ByteArrayInputStream(alumnoEdicion.getFoto());
            Image imgFotoEdicion = new Image(inputFoto);
            ivFoto.setImage(imgFotoEdicion);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void clicSeleccionarFoto(ActionEvent event) {
        FileChooser dialogoImagen = new FileChooser();
        dialogoImagen.setTitle("Selecciona una foto");
        FileChooser.ExtensionFilter filtroImg = new FileChooser.ExtensionFilter("Archivos JPG (*.jpg)", "*.JPG");
        dialogoImagen.getExtensionFilters().add(filtroImg);
        Stage escenarioActual = (Stage) tfNombre.getScene().getWindow();
        archivoFoto = dialogoImagen.showOpenDialog(escenarioActual);
        
        if(archivoFoto != null){
            try {
                BufferedImage bufferImg = ImageIO.read(archivoFoto);
                Image imagenFoto = SwingFXUtils.toFXImage(bufferImg, null);
                ivFoto.setImage(imagenFoto);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    private void cargarListaFacultades(){
        listaFacultades = FXCollections.observableArrayList();
        try {
            ArrayList<Facultad> facultadesBD = FacultadDAO.obtenerFacultades();
            listaFacultades.addAll(facultadesBD);
            cbFacultad.setItems(listaFacultades);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void cargarListaCarreras(int idFacultad){
        listaCarreras = FXCollections.observableArrayList();
        try {
            ArrayList<Carrera> carrerasBD = 
                    CarreraDAO.obtenerCarreraFacultad(idFacultad);
            listaCarreras.addAll(carrerasBD);
            cbCarrera.setItems(listaCarreras);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void clicGuardar(ActionEvent event) {
        String matricula = tfMatricula.getText();
        String nombre = tfNombre.getText();
        String apellidoPaterno = tfApellidoPaterno.getText();
        String apellidoMaterno = tfApellidoMaterno.getText();
        String correo = tfCorreo.getText();
        String fechaNacimiento = tfFechaNacimiento.getText();
        Carrera carreraSeleccionada = cbCarrera.getSelectionModel().getSelectedItem();
        int idCarrera = carreraSeleccionada.getIdCarrera();
        
        // TO DO Validacion de datos tanto nuevo como edición
        // TODOS son requeridos
        
        Alumno alumno = new Alumno();
        alumno.setMatricula(matricula);
        alumno.setNombre(nombre);
        alumno.setApellidoPaterno(apellidoPaterno);
        alumno.setApellidoMaterno(apellidoMaterno);
        alumno.setCorreo(correo);
        alumno.setFechaNacimiento(fechaNacimiento);
        alumno.setIdCarrera(idCarrera);
        
        if(esEdicion){
            alumno.setIdAlumno(alumnoEdicion.getIdAlumno());
            if(archivoFoto != null){
                try {
                    alumno.setFoto(Files.readAllBytes(archivoFoto.toPath()));
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }else{
                alumno.setFoto(alumnoEdicion.getFoto());
            }
            guardarRegistroEditado(alumno);
        }else{
            guardarRegistroNuevo(alumno);
        }
        
    }

    @FXML
    private void clicCancelar(ActionEvent event) {
        cerrarVentana();
    }
    
    private void guardarRegistroNuevo(Alumno alumnoNuevo){
        try {
            ResultadoOperacion resultadoGuardar = 
                    AlumnoDAO.registrarAlumno(alumnoNuevo, archivoFoto);
            if(!resultadoGuardar.isError()){
                Utilidades.mostrarAlertaSimple("Alumno registrado", 
                        resultadoGuardar.getMensaje(), Alert.AlertType.INFORMATION);
                String nombreCompleto = alumnoNuevo.getNombre() + " " + alumnoNuevo.getApellidoPaterno() 
                        + " " + alumnoNuevo.getApellidoMaterno();
                notificacion.notificarRegistroNuevo(nombreCompleto);
                cerrarVentana();
            }else{
                Utilidades.mostrarAlertaSimple("Error el guardar", 
                        resultadoGuardar.getMensaje(), Alert.AlertType.ERROR);
            }
        } catch (SQLException e) {
                Utilidades.mostrarAlertaSimple("Error de conexión", e.getMessage(), 
                        Alert.AlertType.ERROR);
        }
    }
    
    private void guardarRegistroEditado(Alumno alumnoEdicion){
        try {
            ResultadoOperacion resultadoEditar = 
                    AlumnoDAO.editarAlumno(alumnoEdicion, alumnoEdicion.getFoto());
            if(!resultadoEditar.isError()){
                Utilidades.mostrarAlertaSimple("Alumno editado", 
                        resultadoEditar.getMensaje(), Alert.AlertType.INFORMATION);
                String nombreCompleto = alumnoEdicion.getNombre() + " " + alumnoEdicion.getApellidoPaterno() 
                        + " " + alumnoEdicion.getApellidoMaterno();
                notificacion.notificarRegistroEditado(nombreCompleto);
                cerrarVentana();
            }else{
                Utilidades.mostrarAlertaSimple("Error el editar", 
                        resultadoEditar.getMensaje(), Alert.AlertType.ERROR);
            }
        } catch (SQLException e) {
                Utilidades.mostrarAlertaSimple("Error de conexión", e.getMessage(), 
                        Alert.AlertType.ERROR);
        }
    }
    
    private void cerrarVentana(){
        Stage escenarioPrincipal = (Stage) tfNombre.getScene().getWindow();
        escenarioPrincipal.close();
    }

    private int obtenerPosicionFacultad(int idFacultad){
        for (int i = 0; i < listaFacultades.size(); i++) {
            if(listaFacultades.get(i).getIdFacultad() == idFacultad ){
                return i;
            }
        }
        return 0;
    }
    
    private int obtenerPosicionCarrera(int idCarrera){
        for (int i = 0; i < listaCarreras.size(); i++) {
            if(listaCarreras.get(i).getIdCarrera() == idCarrera){
                return i;
            }
        }
        return 0;
    }
}
