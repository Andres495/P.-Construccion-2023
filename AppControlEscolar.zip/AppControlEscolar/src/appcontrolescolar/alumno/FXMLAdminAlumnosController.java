package appcontrolescolar.alumno;

import appcontrolescolar.interfaces.RespuestaFormulario;
import appcontrolescolar.modelo.dao.AlumnoDAO;
import appcontrolescolar.modelo.pojo.Alumno;
import appcontrolescolar.modelo.pojo.ResultadoOperacion;
import appcontrolescolar.util.Utilidades;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;


public class FXMLAdminAlumnosController implements Initializable,  RespuestaFormulario {

    @FXML
    private TextField tfBuscar;
    @FXML
    private TableView<Alumno> tvAlumnos;
    @FXML
    private TableColumn colMatricula;
    @FXML
    private TableColumn colNombre;
    @FXML
    private TableColumn colApellidoPaterno;
    @FXML
    private TableColumn colApellidoMaterno;
    @FXML
    private TableColumn colCorreo;
    @FXML
    private TableColumn colCarrera;
    @FXML
    private TableColumn colFacultad;
    
    ObservableList<Alumno> listaAlumnos;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {   
        configurarTabla();
        cargarDatosTabla();
        inicializarBusquedaAlumno();
    }

    private void configurarTabla(){
        colMatricula.setCellValueFactory(new PropertyValueFactory("matricula"));
        colNombre.setCellValueFactory(new PropertyValueFactory("nombre"));
        colApellidoPaterno.setCellValueFactory(new PropertyValueFactory("apellidoPaterno"));
        colApellidoMaterno.setCellValueFactory(new PropertyValueFactory("apellidoMaterno"));
        colCorreo.setCellValueFactory(new PropertyValueFactory("correo"));
        colCarrera.setCellValueFactory(new PropertyValueFactory("carrera"));
        colFacultad.setCellValueFactory(new PropertyValueFactory("facultad"));
    }
    
    private void cargarDatosTabla(){
        try {
            listaAlumnos = FXCollections.observableArrayList();
            ArrayList<Alumno> alumnoBD = AlumnoDAO.obtenerAlumnos();
            listaAlumnos.addAll(alumnoBD);
            tvAlumnos.setItems(listaAlumnos);
        } catch (SQLException | NullPointerException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void clicBtnAgregar(ActionEvent event) {
        irFormulario(null);
    }

    @FXML
    private void clicBtnModificar(ActionEvent event) {
        Alumno alumnoEdicion = verificarAlumnoSeleccionado();
        if(alumnoEdicion!=null)
            irFormulario(alumnoEdicion);
        else
            Utilidades.mostrarAlertaSimple("Selección obligatoria", 
                    "Debes seleccionar algún registro de la tabla para su edición", Alert.AlertType.WARNING);
    }

    @FXML
    private void clicBtnEliminar(ActionEvent event) {
        Alumno alumnoEliminacion = verificarAlumnoSeleccionado();
        if(alumnoEliminacion != null){
            boolean eliminar = Utilidades.mostrarDialogoConfirmacion("Eliminar registro de alumno", 
                    "¿Deseas eliminar la información del alumno "+alumnoEliminacion.toString()+"?");
            if(eliminar){
                try {
                    ResultadoOperacion resultado = AlumnoDAO.eliminarAlumno(alumnoEliminacion.getIdAlumno());
                    if(!resultado.isError()){
                        Utilidades.mostrarAlertaSimple("Registro eliminado", resultado.getMensaje(), 
                                Alert.AlertType.INFORMATION);
                        cargarDatosTabla();
                        inicializarBusquedaAlumno();
                    }else{
                        Utilidades.mostrarAlertaSimple("Operación incorrecta", resultado.getMensaje(), 
                                Alert.AlertType.ERROR);
                    }
                } catch (SQLException e) {
                    Utilidades.mostrarAlertaSimple("ERROR", e.getMessage(), 
                                Alert.AlertType.ERROR);
                }
            }
        }else{
            Utilidades.mostrarAlertaSimple("Selección obligatoria", 
                    "Debes seleccionar algún registro de la tabla para su eliminación", Alert.AlertType.WARNING);
        }
    }
    
    private void irFormulario(Alumno alumno){
        try {
            FXMLLoader accesoControlador = 
                    new FXMLLoader(getClass().getResource("FXMLFormularioAlumno.fxml"));
            Parent vista = accesoControlador.load();
            
            FXMLFormularioAlumnoController formulario = 
                    accesoControlador.getController();
            formulario.inicializarValores( this , alumno);
            Scene escenaFormulario = new Scene(vista);
            Stage escenarioNuevo = new Stage();
            escenarioNuevo.setScene(escenaFormulario);
            escenarioNuevo.initModality(Modality.APPLICATION_MODAL);
            escenarioNuevo.showAndWait();
        } catch (IOException e) {
            Utilidades.mostrarAlertaSimple("Error", "No se puede mostrar la pantalla de formulario", 
                    Alert.AlertType.ERROR);
        }
    }

    @Override
    public void notificarRegistroNuevo(String mensaje) {
        System.out.println("Alumno agregado: "+mensaje);
        cargarDatosTabla();
        inicializarBusquedaAlumno();
    }

    @Override
    public void notificarRegistroEditado(String mensaje) {
        System.out.println("Alumno editado: "+mensaje);
        cargarDatosTabla();
        inicializarBusquedaAlumno();
    }
    
    private Alumno verificarAlumnoSeleccionado(){
        int filaSeleccionada = tvAlumnos.getSelectionModel().getSelectedIndex();
        return (filaSeleccionada >= 0) ? listaAlumnos.get(filaSeleccionada) : null ;
    }
    
    // Busqueda realizada por campos de: Nombre y Matricula
    private void inicializarBusquedaAlumno(){
        if(listaAlumnos.size() > 0){
            FilteredList<Alumno> filtroDato = new FilteredList<>(listaAlumnos, p -> true);
            
            tfBuscar.textProperty().addListener(new ChangeListener<String>(){
                
                @Override
                public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                    filtroDato.setPredicate(busqueda -> {
                        
                        if(newValue == null || newValue.isEmpty()){
                            return true;
                        }
                        
                        String lowerCaseFilter = newValue.toLowerCase();
                        // Condicion para buscar por nombre
                        if(busqueda.getNombre().toLowerCase().contains(lowerCaseFilter)){
                            return true;
                        }else if(busqueda.getMatricula().toLowerCase().contains(lowerCaseFilter)){ // Condicion para buscar por matricula
                            return true;
                        }
                        return false;
                    });
                }
            
            });
            
            SortedList<Alumno> sortedData = new SortedList<>(filtroDato);
            sortedData.comparatorProperty().bind(tvAlumnos.comparatorProperty());
            tvAlumnos.setItems(sortedData);
            
        }
    }
    
}
