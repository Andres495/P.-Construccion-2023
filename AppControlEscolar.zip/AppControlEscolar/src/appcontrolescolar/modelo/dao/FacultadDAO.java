package appcontrolescolar.modelo.dao;

import appcontrolescolar.modelo.ConexionBD;
import appcontrolescolar.modelo.pojo.Facultad;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class FacultadDAO {
    
    public static ArrayList<Facultad> obtenerFacultades() throws SQLException{
        ArrayList<Facultad> facultades = null;
        Connection conexionBD = ConexionBD.abrirConexionBD();
        if(conexionBD != null){
            try {
                String consulta = "SELECT idFacultad, nombre FROM facultad";
                PreparedStatement prepararConsulta = conexionBD.prepareStatement(consulta);
                ResultSet resultadoConsulta = prepararConsulta.executeQuery();
                facultades = new ArrayList<>();
                while(resultadoConsulta.next()){
                    Facultad fac = new Facultad();
                    fac.setIdFacultad(resultadoConsulta.getInt("idFacultad"));
                    fac.setNombre(resultadoConsulta.getString("nombre"));
                    facultades.add(fac);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally{
                conexionBD.close();
            }
        }
        return facultades;
    }
}
