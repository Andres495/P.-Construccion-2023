package appcontrolescolar.modelo.dao;

import appcontrolescolar.modelo.ConexionBD;
import appcontrolescolar.modelo.pojo.Alumno;
import appcontrolescolar.modelo.pojo.ResultadoOperacion;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class AlumnoDAO {
    
    public static ArrayList<Alumno> obtenerAlumnos() throws SQLException{
        ArrayList<Alumno> alumnosBD = null;
        Connection conexionBD = ConexionBD.abrirConexionBD();
        if(conexionBD != null){
            try {
                String consulta = "SELECT idAlumno,matricula, alumno.nombre, apellidoPaterno, " +
                    "apellidoMaterno, correo,fechaNacimiento, alumno.idCarrera, " +
                    "carrera.nombre as 'carrera', carrera.idFacultad, " +
                    "facultad.nombre as 'facultad', foto " +
                    "FROM alumno " +
                    "INNER JOIN carrera ON alumno.idCarrera = carrera.idCarrera " +
                    "INNER JOIN facultad ON carrera.idFacultad = facultad.idFacultad";
                PreparedStatement consultaObtenerTodos = conexionBD.prepareStatement(consulta);
                ResultSet resultadoConsulta = consultaObtenerTodos.executeQuery();
                alumnosBD = new ArrayList<>();
                while(resultadoConsulta.next()){
                    Alumno temp = new Alumno();
                    temp.setIdAlumno(resultadoConsulta.getInt("idAlumno"));
                    temp.setMatricula(resultadoConsulta.getString("matricula"));
                    temp.setNombre(resultadoConsulta.getString("nombre"));
                    temp.setApellidoPaterno(resultadoConsulta.getString("apellidoPaterno"));
                    temp.setApellidoMaterno(resultadoConsulta.getString("apellidoMaterno"));
                    temp.setCorreo(resultadoConsulta.getString("correo"));
                    temp.setFechaNacimiento(resultadoConsulta.getString("fechaNacimiento"));
                    temp.setIdCarrera(resultadoConsulta.getInt("idCarrera"));
                    temp.setCarrera(resultadoConsulta.getString("carrera"));
                    temp.setIdFacultad(resultadoConsulta.getInt("idFacultad"));
                    temp.setFacultad(resultadoConsulta.getString("facultad"));
                    temp.setFoto(resultadoConsulta.getBytes("foto"));
                    alumnosBD.add(temp);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally{
                conexionBD.close();
            }
        }
        return alumnosBD;
    }
    
    
    public static ResultadoOperacion registrarAlumno(Alumno alumnoNuevo, File foto) throws SQLException{
        ResultadoOperacion respuesta = new ResultadoOperacion();
        respuesta.setError(true);
        respuesta.setNumeroFilasAfectadas(-1);
        
        Connection conexionBD = ConexionBD.abrirConexionBD();
        if(conexionBD != null){
            try {
                String sentencia = "INSERT INTO alumno (matricula, nombre, apellidoPaterno, apellidoMaterno, correo, fechaNacimiento, idCarrera, foto) "
                                    +" VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement prepararSentencia = conexionBD.prepareStatement(sentencia);
                prepararSentencia.setString(1, alumnoNuevo.getMatricula());
                prepararSentencia.setString(2, alumnoNuevo.getNombre());
                prepararSentencia.setString(3, alumnoNuevo.getApellidoPaterno());
                prepararSentencia.setString(4, alumnoNuevo.getApellidoMaterno());
                prepararSentencia.setString(5, alumnoNuevo.getCorreo());
                prepararSentencia.setString(6, alumnoNuevo.getFechaNacimiento());
                prepararSentencia.setInt(7, alumnoNuevo.getIdCarrera());
                
                FileInputStream fotoAlumno = new FileInputStream(foto);
                prepararSentencia.setBlob(8, fotoAlumno);
                int numeroFilas = prepararSentencia.executeUpdate();
                if(numeroFilas > 0){
                    respuesta.setError(false);
                    respuesta.setMensaje("Alumno agregado correctamente.");
                    respuesta.setNumeroFilasAfectadas(numeroFilas);
                }else{
                    respuesta.setMensaje("No se pudo registrar la información del alumno.");
                }
            } catch (SQLException e) {
                respuesta.setMensaje(e.getMessage());
            } catch(FileNotFoundException f) {
                respuesta.setMensaje(f.getMessage());
            }finally{
                conexionBD.close();
            }
        }else{
            respuesta.setMensaje("Por el momento no hay conexión con la base de datos...");
        }
        return respuesta;
    }
    
    
    
    public static ResultadoOperacion editarAlumno(Alumno alumnoEdicion, byte[] foto) throws SQLException{
        ResultadoOperacion respuesta = new ResultadoOperacion();
        respuesta.setError(true);
        respuesta.setNumeroFilasAfectadas(-1);
        
        Connection conexionBD = ConexionBD.abrirConexionBD();
        if(conexionBD != null){
            try {
                String sentencia = "UPDATE alumno SET nombre = ?, apellidoPaterno = ?, apellidoMaterno = ?, correo = ?, fechaNacimiento = ?, idCarrera = ?, foto = ? "
                                    +" WHERE idAlumno = ?";
                PreparedStatement prepararSentencia = conexionBD.prepareStatement(sentencia);
                prepararSentencia.setString(1, alumnoEdicion.getNombre());
                prepararSentencia.setString(2, alumnoEdicion.getApellidoPaterno());
                prepararSentencia.setString(3, alumnoEdicion.getApellidoMaterno());
                prepararSentencia.setString(4, alumnoEdicion.getCorreo());
                prepararSentencia.setString(5, alumnoEdicion.getFechaNacimiento());
                prepararSentencia.setInt(6, alumnoEdicion.getIdCarrera());
                prepararSentencia.setBytes(7, foto);
                prepararSentencia.setInt(8, alumnoEdicion.getIdAlumno());
                
                int numeroFilas = prepararSentencia.executeUpdate();
                if(numeroFilas > 0){
                    respuesta.setError(false);
                    respuesta.setMensaje("Alumno editado correctamente.");
                    respuesta.setNumeroFilasAfectadas(numeroFilas);
                }else{
                    respuesta.setMensaje("No se pudo editar la información del alumno.");
                }
            } catch (SQLException e) {
                respuesta.setMensaje(e.getMessage());
            } catch(NullPointerException f) {
                respuesta.setMensaje(f.getMessage());
            }finally{
                conexionBD.close();
            }
        }else{
            respuesta.setMensaje("Por el momento no hay conexión con la base de datos...");
        }
        return respuesta;
    }
    
    
    public static ResultadoOperacion eliminarAlumno(int idAlumno) throws SQLException{
        ResultadoOperacion respuesta = new ResultadoOperacion();
        respuesta.setError(true);
        respuesta.setNumeroFilasAfectadas(-1);
        
        Connection conexionBD = ConexionBD.abrirConexionBD();
        if(conexionBD != null){
            try {
                String sentencia = "DELETE FROM alumno WHERE idAlumno = ? ";                
                PreparedStatement prepararSentencia = conexionBD.prepareStatement(sentencia);
                prepararSentencia.setInt(1, idAlumno);
                
                int numeroFilas = prepararSentencia.executeUpdate();
                if(numeroFilas > 0){
                    respuesta.setError(false);
                    respuesta.setMensaje("Alumno eliminado correctamente.");
                    respuesta.setNumeroFilasAfectadas(numeroFilas);
                }else{
                    respuesta.setMensaje("No se pudo eliminar la información del alumno.");
                }
            } catch (SQLException e) {
                respuesta.setMensaje(e.getMessage());
            } finally{
                conexionBD.close();
            }
        }else{
            respuesta.setMensaje("Por el momento no hay conexión con la base de datos...");
        }
        return respuesta;
    }
    
}
